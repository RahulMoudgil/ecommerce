Build a blog with meanstack and mongodb
=====

A blog made out of the meanstack. Uses mongoose, angular, express and the node.js and the mongodbs for realz


#### Getting started
```
$ git clone <this_repo>
$ npm install
$ node server 
```

**Tutorial part 1:** http://readyourlessons.com//

**Questions?** [Hit me up on facebook](https://www.facebook.com/ashutosh.kr.upadhyay)
